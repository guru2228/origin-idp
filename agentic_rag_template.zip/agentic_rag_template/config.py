import os
from dotenv import load_dotenv

load_dotenv()

# Database configuration
DATABASE_URL = os.getenv("DATABASE_URL")

# Embedding and LLM model names
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "openai-embedding-model")
LLM_MODEL = os.getenv("LLM_MODEL", "openai-chat-model")
