from agno.agent import AgnoAgent
from agno.rag import RAGPipeline
from agno.vectorstores.pgvector import PGVectorStore
from agno.embeddings import EmbeddingModel

class AgenticRAG:
    def __init__(self, db_url, embedding_model, llm_model):
        # Initialize vector store
        self.vector_store = PGVectorStore(
            db_url=db_url,
            embedding_model=EmbeddingModel(embedding_model)
        )
        # Initialize RAG pipeline
        self.rag = RAGPipeline(
            vector_store=self.vector_store,
            llm_model=llm_model
        )

    def ingest(self, text, metadata=None):
        """
        Ingest raw text into the vector store.
        """
        self.vector_store.add_documents([{
            "text": text,
            "metadata": metadata or {}
        }])

    async def stream_query(self, query):
        """
        Stream response tokens from the RAG pipeline.
        """
        async for token in self.rag.stream(query):
            yield token
