import os
import requests
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
from config import DATABASE_URL, EMBEDDING_MODEL, LLM_MODEL
from rag_agent import AgenticRAG

app = FastAPI()
agent = AgenticRAG(
    db_url=DATABASE_URL,
    embedding_model=EMBEDDING_MODEL,
    llm_model=LLM_MODEL
)

@app.post("/ingest")
async def ingest_content(file: UploadFile = File(None), url: str = None):
    if not file and not url:
        raise HTTPException(status_code=400, detail="Provide a file or URL")
    if file:
        content = (await file.read()).decode('utf-8')
    else:
        resp = requests.get(url)
        if resp.status_code != 200:
            raise HTTPException(status_code=400, detail="Failed to fetch URL content")
        content = resp.text
    agent.ingest(content, metadata={"source": url or file.filename})
    return {"status": "ingested"}

@app.post("/query")
async def query_content(query: str):
    async def token_generator():
        async for token in agent.stream_query(query):
            yield token
    return StreamingResponse(token_generator(), media_type="text/event-stream")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", 8000)), reload=True)
