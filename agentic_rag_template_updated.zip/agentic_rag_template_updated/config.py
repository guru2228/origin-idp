import os
from dotenv import load_dotenv

load_dotenv()

# General configuration
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "openai-embedding-model")
LLM_MODEL = os.getenv("LLM_MODEL", "openai-chat-model")
VECTOR_STORE_TYPE = os.getenv("VECTOR_STORE_TYPE", "pgvector")

# Vector store configs
VECTOR_STORE_CONFIG = {
    "pgvector": {
        "db_url": os.getenv("DATABASE_URL")
    },
    "chroma": {
        "persist_directory": os.getenv("CHROMA_PERSIST_DIR", "./chroma")
    },
    "qdrant": {
        "url": os.getenv("QDRANT_URL"),
        "api_key": os.getenv("QDRANT_API_KEY")
    },
    "weaviate": {
        "url": os.getenv("WEAVIATE_URL"),
        "api_key": os.getenv("WEAVIATE_API_KEY")
    },
    "lancedb": {
        "persist_directory": os.getenv("LANCEDB_PERSIST_DIR", "./lancedb")
    }
}
