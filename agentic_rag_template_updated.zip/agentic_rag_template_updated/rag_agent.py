from agno.rag import RAGPipeline
from agno.embeddings import EmbeddingModel
from agno.vectorstores.pgvector import PGVectorStore
from agno.vectorstores.chromadb import ChromaStore
from agno.vectorstores.qdrant import QdrantStore
from agno.vectorstores.weaviate import WeaviateStore
from agno.vectorstores.lancedb import LanceDBStore
from config import VECTOR_STORE_TYPE, VECTOR_STORE_CONFIG, EMBEDDING_MODEL

class AgenticRAG:
    def __init__(self, llm_model):
        # Initialize embedding
        embedding = EmbeddingModel(EMBEDDING_MODEL)
        # Choose vector store
        store_conf = VECTOR_STORE_CONFIG.get(VECTOR_STORE_TYPE)
        if VECTOR_STORE_TYPE == "pgvector":
            self.vector_store = PGVectorStore(db_url=store_conf["db_url"], embedding_model=embedding)
        elif VECTOR_STORE_TYPE == "chroma":
            self.vector_store = ChromaStore(persist_directory=store_conf["persist_directory"], embedding_model=embedding)
        elif VECTOR_STORE_TYPE == "qdrant":
            self.vector_store = QdrantStore(url=store_conf["url"], api_key=store_conf["api_key"], embedding_model=embedding)
        elif VECTOR_STORE_TYPE == "weaviate":
            self.vector_store = WeaviateStore(url=store_conf["url"], api_key=store_conf["api_key"], embedding_model=embedding)
        elif VECTOR_STORE_TYPE == "lancedb":
            self.vector_store = LanceDBStore(persist_directory=store_conf["persist_directory"], embedding_model=embedding)
        else:
            raise ValueError(f"Unsupported VECTOR_STORE_TYPE: {VECTOR_STORE_TYPE}")

        # Initialize RAG pipeline
        self.rag = RAGPipeline(vector_store=self.vector_store, llm_model=llm_model)

    def ingest(self, text, metadata=None):
        """Ingest raw text into the vector store."""
        self.vector_store.add_documents([{
            "text": text,
            "metadata": metadata or {}
        }])

    async def stream_query(self, query):
        """Stream response tokens from the RAG pipeline."""
        async for token in self.rag.stream(query):
            yield token
